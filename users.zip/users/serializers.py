# users/serializers.py
from rest_framework import serializers
from users.models import User

class UserSerializer(serializers.ModelSerializer):
    # DRF will automatically look for a model attribute/property
    # with the same name, so no `source=` is required.
    is_admin = serializers.BooleanField(read_only=True)

    class Meta:
        model  = User
        fields = ('id', 'username', 'full_name', 'role', 'is_admin')
