from rest_framework import status, permissions
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.views import TokenObtainPairView

from .serializers import UserSerializer

from rest_framework_simplejwt.views import TokenObtainPairView
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from rest_framework.response import Response
from .serializers import UserSerializer

class LoginView(TokenObtainPairView):
    """
    POST /api/auth/login/  ->  returns refresh, access and user info
    """

    def post(self, request, *args, **kwargs):
        # run the same validation TokenObtainPairView does
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        user     = serializer.user
        refresh  = serializer.validated_data["refresh"]
        access   = serializer.validated_data["access"]

        return Response(
            {
                "refresh": str(refresh),
                "access":  str(access),
                "user":    UserSerializer(user).data,
            }
        )


class LogoutView(APIView):
    permission_classes = (permissions.IsAuthenticated,)

    def post(self, request):
        refresh = request.data.get('refresh')
        if not refresh:
            return Response({'detail': 'Refresh token required'}, status=status.HTTP_400_BAD_REQUEST)
        try:
            token = RefreshToken(refresh)
            token.blacklist()
        except Exception:
            pass
        return Response(status=status.HTTP_204_NO_CONTENT)
